<?php

/************ THIS FUNCTIONS FILE IS FOR CHILD THEME FUNCTIONS ONLY ************/

# ---------------------------------------
# IMPORT STYLES & SCRIPTS
# ---------------------------------------

add_action( 'wp_enqueue_scripts', 'theme_enqueue_scripts' );
$site_url = "https://www.bidslotmarketingcorp.com/";

function theme_enqueue_scripts() {
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/css/genericons/genericons.css');
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/css/customizer.css');
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/css/editor-style.css');
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/css/flexslider.css');
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/css/theme-info.css');
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/css/themezee-related-posts.css');
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/css/themezee-widget-bundle.css');
    //Bootstrap Scripts
    wp_enqueue_style('bootstrap-style', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css');
    //DataTable Scripts
    wp_enqueue_style('datatables-style', 'https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css');
    wp_enqueue_style('datatables-style', 'https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css');
    wp_enqueue_style('datatables-style', 'https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css');
    //FontAwesome
    wp_enqueue_style('fontAwesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
}

# ---------------------------------------
# REMOVE AUTOP
# ---------------------------------------

remove_filter( 'the_content', 'wpautop' );
remove_filter( 'the_excerpt', 'wpautop' );

# ---------------------------------------
#
# LOGIN FUNCTIONS
#
# ---------------------------------------
if(array_key_exists('action', $_GET))
switch($_GET['action']){
    case 'getMerchants':
        echo Forms::getMerchants();
        break;
    default:
        null;
}

class Forms {
    public static function getMerchants() {
        global $wpdb;
        $merchants = $wpdb->get_results("SELECT u.id, u.display_name FROM va_users u LEFT JOIN va_assistants a ON u.id = a.id WHERE a.id IS NULL");
        
        return json_encode($merchants);
    }
}

# ---------------------------------------
# MOD MAIN MENU & ADD LOGIN/LOGOUT
# ---------------------------------------

add_filter('wp_nav_menu_items', 'login_logout', 10,2);
add_filter('wp_nav_menu_items', 'user_menu_mods', 10, 2);

function login_logout($items, $args) {
    //Only on Primary Menu
    if ($args->theme_location != 'primary') {
        return $items;
    }
    //If redirect is to the home page, no redirect
    //$redirect = (is_home()) ? false: get_permalink();
    $redirect = (is_user_logged_in()) ? get_home_url() : $site_url.'dash';

    /*if( is_user_logged_in( ) ) {$link = '<a href="' . wp_logout_url( $redirect ) . '" title="' .  __( 'Logout' ) .'">' . __( 'Logout' ) . '</a>';}
    else {$link = '<a href="' . wp_login_url( $redirect  ) . '" title="' .  __( 'Login' ) .'">' . __( 'Login' ) . '</a>';}*/

    ob_start();
    wp_loginout($redirect);
    $link = ob_get_contents();
    
    ob_end_clean();
    
    if (is_user_logged_in()){
        $countItem = '';
        if(current_user_can('remove_users')){
            global $wpdb;
            $count = $wpdb->get_results("SELECT COUNT(id) as 'Count' FROM va_job_requests WHERE assigned_to = '".wp_get_current_user()->display_name."' AND status NOT IN ('Complete', 'Canceled')")[0]->Count;
            $countItem = '<li class="menu-item menu-type-link"><span class="label label-primary">'.$count.'</span></li>';
        };
        $items .= '<li class="menu-item-has-children"><a href="'.get_home_url().'/profile">'.wp_get_current_user()->display_name.'</a><ul class="sub-menu"><li><a href="'.get_home_url().'/shop">Shop</a></li><li id="log-in-out-link" class="menu-item menu-type-link">'.$link.'</li></ul>';
        $items .= $countItem;
        
        return $items;
    }
    else {
        return $items .= '<li id="log-in-out-link" class="menu-item menu-type-link"><a href="#" data-toggle="modal" data-target="#loginModal">Login</a></li>';
    };
}

function user_menu_mods($items, $args) {
    if ($args->theme_location == 'primary') {
        $moditems = preg_split('/<\/li>/',$items, -1, PREG_SPLIT_DELIM_CAPTURE);
        if (!is_user_logged_in()) {      
            $delete = array($moditems[0], $moditems[1], $moditems[2], $moditems[3]);
            $moditems = array_diff_key($moditems, $delete);
            $items = implode('',$moditems);

            return $items;
        }
        else {
            if (current_user_can('remove_users')) {
                $delete = array($moditems[4], $moditems[5]);
                $moditems = array_diff($moditems, $delete);
                $items = implode('',$moditems);
                
                return $items;
            }
            else {
                $delete = array($moditems[0],$moditems[1], $moditems[2], $moditems[3], $moditems[4]);
                $moditems = array_diff($moditems, $delete);
                array_unshift ($moditems,'<li class="menu-item-has-children" aria-haspopup="true" aria-expanded="false"><span class="submenu-dropdown-toggle"></span><a href="/task-requests">Task Requests</a><ul class="sub-menu" style="visibility:hidden;"><li id="reporting-link"><a href="'.get_home_url().'/reporting">Reporting</a></li></ul></li>');
                $items = implode('',$moditems);
                
                return $items;
            };
        };
    }
    else {
        return $items;
    };
}

# -----------------------------------
# REDIRECT ALL LOGINS
# -----------------------------------

add_filter('login_redirect','user_login_redirect', 10, 2);

function user_login_redirect($redirect_to, $request) {
    $redirect_to = get_bloginfo('url').'/task-requests/';
    // $redirect_to = get_bloginfo('url');
    // var_dump($redirect_to, "redirect");exit;
    return $redirect_to;
}

# -----------------------------------
# CUSTOM REDIRECT TO URL IF PROVIDED
# -----------------------------------

add_filter('login_redirect','from_email_redirect', 9, 2);

function from_email_redirect($redirect_to, $request) {
    $redirect_to = $_REQUEST['redirect_to'];
    preg_match("/(?=(^https:\/\/va\.)).+/", $redirect_to, $match);
    if ($match[1] == 'https://va.') {
        return $redirect_to;
    };
}

# --------------------------------------------
# REMOVE REDIRECT TO WOOCOMMERCE MY-ACCOUNT
# --------------------------------------------

add_filter('woocommerce_prevent_admin_access','__return_false');

# -----------------------------------
# LOGIN PAGE CHANGES
# -----------------------------------

add_action('login_enqueue_scripts', 'login_styles');

function login_styles() {
    ?>
<style type="text/css">
    .login h1 a {
        background-image:url($site_url.'wp-content/uploads/2016/08/valogo2.png') !important;
        width:auto !important;
        background-size:contain !important;
    }
</style>
<?php
}

# ------------------------------------------------------------------
#
# ADD/REMOVE ADMINS TO/FROM VA_ASSISTANTS
#
# ------------------------------------------------------------------

add_action('user_register', 'add_admin', 10, 1);
add_action('profile_update', 'change_admin', 10, 2);
add_action('delete_user', 'remove_admin', 10, 1);

function add_admin($user_id) {
    global $wpdb;
    if ($_POST['role'] === 'Administrator' || $_POST['role'] === 'super_admin') {
        $name = $_POST['first_name'].' '.$_POST['last_name'];
        $wpdb->insert('va_assistants', array('id'=>$user_id,'name'=>$name, 'email'=>$_POST['email']));
    };
}

function change_admin($user_id, $old_user_data) {
    global $wpdb;
    if ($_POST['role'] === 'Administrator' || $_POST['role'] === 'super_admin') {
        $name = $_POST['first_name'].' '.$_POST['last_name'];
        $wpdb->update('va_assistants', array('name'=>$name, 'email'=>$_POST['email']), array('id'=>$user_id));
    } else {
        $wpdb->delete('va_assistants', array('id'=>$user_id));
    }
}

function remove_admin($user_id) {
    global $wpdb;
    $wpdb->delete('va_assistants', array('id'=>$user_id));
}


# -----------------------------------
# UPDATE USER STATUS
# -----------------------------------

add_action('edit_user_profile_update', 'update_user_status');
 
 function update_user_status($user_id) {
     global $wpdb;
     if (current_user_can('edit_user',$user_id)){
         //get_field() won't work here...
         $status = $_POST['acf']['field_5b105c241d81b'];
         $wpdb->update('va_users', array('user_status' => $status), array('id'=>$user_id)); 
     }
 }

# ------------------------------------------------------------------
#
# PROCESS JOB REQUESTS SUBMISSIONS TO DATABASE
#
# ------------------------------------------------------------------

add_action('gform_after_submission_20','user_job_requests', 10, 2);
add_action('gform_after_submission_17', 'admin_job_requests', 10, 2);
add_action('gform_after_submission_25', 'admin_job_requests', 10, 2);

# ---------------------------------------
# USER JOB REQUESTS
# ---------------------------------------


function user_job_requests($entry, $form) {
    global $wpdb;
    $token = '&s3c-';
    $labels = array();
    $values = array();
    $va_entry = array();
    $timestamp = current_time('mysql');

    //Capture label names
    for ($i=0; $i<sizeof($form['fields']); $i++) {
        $label = $form['fields'][$i]->label;
        array_push($labels, $label);
    }
    
    //Capture form values
    for ($i=1; $i<sizeof($labels)+1; $i++) {
        array_push($values, rgar($entry, $i));
    }
    
    //Assign label names to form values
    for ($i=0; $i<sizeof($values); $i++) {
        $va_entry[$labels[$i]] = $values[$i];
    }
    
    $user_id = get_current_user_id();
    
    $title = str_replace(["—","–"],'-', $va_entry['Title']);
    $description = str_replace(["—","–"],'-', $va_entry['Description']);
    $email_group = implode(',',explode(PHP_EOL,get_field('email_group', $task->user_id)));
    
    $wpdb->insert('va_job_requests',
        array(
            'user_id'       => $user_id,
            'name'          => $va_entry['Name'],
            'email'         => $va_entry['Email'],
            'email_group'   => $email_group,
            'category'      => $va_entry['Category'],
            'title'         => $title,
            'description'   => $description,
            'task_entered'  => $timestamp,
            'file'          => $va_entry['File'],
            'complete_by'   => $va_entry['Complete By'],
            'complete_time' => $va_entry['Complete Time'],
            'recurring'     => $va_entry['Recurring Task'],
            'frequency'     => $va_entry['Frequency']            
        )
    );
    
    # FOR DEBUGGING
  
    //echo 'Labels: '.print_r($labels);
    //echo 'Values: '.print_r($values);
    
    // foreach ($va_entry as $key=>$value) {
    //     file_put_contents('jrEntryData.txt', $token.$key.'->'.$value, FILE_APPEND);
    // }
    // file_put_contents('jrEntryData.txt', "\n", FILE_APPEND);
}

# ---------------------------------------
# ADMIN JOB REQUESTS (Task Creation)
# ---------------------------------------

function admin_job_requests($entry, $form) {
	
    global $wpdb;
    $token = '&s3c-';
    $labels = array();
    $values = array();
    $va_entry = array();
    $timestamp = current_time('mysql');
    $sttime = $_GET['sttime'];
    $current_id = $wpdb->get_results("SELECT id FROM `va_job_requests` ORDER BY id DESC limit 1")[0]->id;
    $next_id = $current_id+1;
    
    for ($i=0; $i<sizeof($form['fields']); $i++) {
        $label = $form['fields'][$i]->label;
        $value = rgar($entry, $form['fields'][$i]->id);
        $value = $value ? $value : '';
        $va_entry[$label] = $value;        
    };

    $user_id = $va_entry['User Id'] ?: $va_entry['Client Name'] ?: $va_entry['Company Name'];
    $user = $wpdb->get_results("SELECT * FROM va_users WHERE ID = $user_id")[0];
    $client_name = $user->display_name;
    $admin_name = $wpdb->get_results("SELECT name FROM va_assistants WHERE email = '".$va_entry['Admin Email']."'")[0]->name;
    $notes = "";
    if(empty($va_entry['Description'])){		
		$description = str_replace(["—","–"],'-', $va_entry['Details']);
		//$notes = str_replace(["—","–"],'-', $va_entry['Details']);
	} else{
		$description = str_replace(["—","–"],'-', $va_entry['Description']);
	}
	if(empty($va_entry['Title'])){
		$title = 'SCC Ticket Request';
	} else {
		$title = str_replace(["—","–"],'-', $va_entry['Title']);
	}    
    
    $phone = str_replace(["—","–"],'-', $va_entry['Caller Phone Number']);
    $scc_username = str_replace(["—","–"],'-', $va_entry['SCC Username']);
    
	if(empty($va_entry['Company Email Group'])){
		$email_group = implode(',',explode(PHP_EOL,$va_entry['Group Email'])); 
	} else {
		$email_group = implode(',',explode(PHP_EOL,$va_entry['Company Email Group'])); 
    }
    $referral = $va_entry['Referral'] === "Referral" ? $va_entry['Other Referral'] || "Not Given" : $va_entry['Referral'];
	
    //escaping dollar signs - maybe try surrounding with single quotes.
    //$description = str_replace("$", "/$", $description);
    //$description = "'".$description."'";
       
    
    $times['prehours'] = $user->hours;
    
    $preminutes = $user->hours * 60;
    $difference = round((strtotime($timestamp) - strtotime($sttime)) / 60, 0); // in minutes
    $difference = $difference > 2 ? $difference : 2; //Tasks take at least one minute.

    $times['taskhours'] = round($difference / 60, 2);
    $times['remaininghours'] = round(($preminutes - $difference) / 60, 2);
    
    if (!empty($sttime)) { //QUICK TASK REQUEST

        //$extras = $user->counter > 0 ? array('new_counter' => $user->counter + 1) : array('time_elapsed' => $times['taskhours']); //modified Micheal
        $extras = array(
            'new_counter' => $user->counter + 1,
            'time_elapsed' => $times['taskhours']
        ); //added Micheal
        $insert = array_merge(array(
            'user_id'           => $user_id,
            'name'              => $client_name,
            'email'             => $va_entry['Client Email'],
            'email_group'       => $email_group,
            'category'          => $va_entry['Category'],
            'title'             => $title,
            'status'            => 'Complete',
            'assigned_to'       => $admin_name,
            'description'       => $description,
            'referral'          => $referral,
            'address1'          => $va_entry['Address 1'],
            'address2'          => $va_entry['Address 2'],
            'task_entered'      => $sttime,
            'task_start'        => $sttime,
            'task_complete'     => $timestamp,
            'recurring'         => 'No',
            'file'              => $va_entry['File'],
            'company' 	        => $va_entry['Company'],
            'caller_source'     => $va_entry['Caller Source'],
            'caller_name'	    => $va_entry['Caller Name'],
            'caller_email'      => $va_entry['Caller Email Address'],
            'caller_type' 	    => $va_entry['Caller Type'],
            'college_ID_number' => $va_entry['College Id Number'],
            'SCC_Username' 	    => $scc_username,
            'phone_number'      => $phone,
            'agent' 	  	    => $va_entry['Agent'],
            'notes'			    => $notes,
            'task_status'       => $va_entry['Status']
        ), $extras);

        $wpdb->insert('va_job_requests', $insert);

        $uw_emails = array('uwpiedmont.org');
        $email = $user->user_email;
        $spec_user = in_array(substr($email, strpos($email, '@')+1), $uw_emails);

        if($spec_user === true) {
            $corpgroupid = get_field('corporate_group',"user_$user_id"); //Can't use as unique identifier for United Way because other users are within corp groups.
            if($corpgroupid) {
                $corp_query =  $wpdb->get_results("SELECT display_name, hours, counter FROM va_users WHERE ID = $corpgroupid")[0];
            }
        }

        //if($user->counter > 0) { ///modified Micheal
        $new_counter = $spec_user ? $corp_query->counter + 1 : $user->counter + 1;
        $id = $spec_user ? $corpgroupid : $user_id;

        $wpdb->update('va_users', array('counter' => $new_counter), array('ID' => $id));
        //} else {
        if ($spec_user === true) { //Corporate User United Way Only
            if($corpgroupid) {
                $corp_prehours = $corp_query->hours;
                $corp_display_name = $corp_query->display_name;
                $corp_preminutes = $corp_prehours * 60;
                $corp_remaininghours = round(($corp_preminutes - $difference) / 60,2);

                $wpdb->update('va_users', array('hours'=>$corp_remaininghours), array('ID'=>$corpgroupid));
            }
        } else {
            $wpdb->update('va_users', array('hours'=>$times['remaininghours']), array('ID'=>$user_id));
        }
        //}
        $caller_source = $va_entry['Caller Source'];
        $caller_email = $va_entry['Caller Email Address'];

        task_complete_email($form['id'], $next_id, $corpgroupid, $spec_user, $times, $corp_display_name, $corp_prehours, $corp_remaininghours, $caller_email, $caller_source);
        
    } else { //NORMAL TASK REQUEST
        $wpdb->insert('va_job_requests', 
        array(
            'user_id'       => $user_id,
            'name'          => $client_name,
            'email'         => $va_entry['Client Email'],
            'email_group'   => $email_group,
            'category'      => $va_entry['Category'],
            'title'         => $title,
            'description'   => $description,
            'address1'      => $va_entry['Address 1'],
            'address2'      => $va_entry['Address 2'],
            'task_entered'  => $timestamp,
            'complete_by'   => $va_entry['Complete By'],
            'complete_time' => $va_entry['Complete Time'],
            'recurring'     => $va_entry['Recurring Task'],
            'frequency'     => $va_entry['Frequency'],
            'file'          => $va_entry['File'],
            'company' 	    => $va_entry['Company']
        ));
    };
    
    # FOR DEBUGGING

    // die(print_r(
    //     array(
    //         'id'        => $form['id'],
    //         'task_id'   => $next_id,
    //         'corp_id'   => $corpgroupid,
    //         'special'   => $spec_user,
    //         'times'     => implode(', ', $times),
    //         'corp_name' => $corp_display_name,
    //         'corp_pre'  => $corp_prehours,
    //         'corp_re'   => $corp_remaininghours
    //         )
    // ));

    //echo "<script type='text/javascript'>console.log($labels)</script>";
    //echo 'Labels: '.print_r($labels);
    //echo 'Values: '.print_r($values);
    
    // foreach ($va_entry as $key=>$value) {
    //     file_put_contents('jrEntryData.txt', $key.'->'.$value, FILE_APPEND);
    // }
    // file_put_contents('jrEntryData.txt', "\n", FILE_APPEND);
    
    echo "<script type='text/javascript'>window.close();</script>";
}

# ---------------------------------------
# ADD EMAIL FILE(S) TO VA_JOB_REQUESTS
# ---------------------------------------

add_action('gform_after_submission_9', 'upload_email_file', 10, 2);

function upload_email_file($entry, $form) {
    global $wpdb;
    $id = $_GET['id'];
    $fileslots = $wpdb->get_results("SELECT email_file_1, email_file_2, email_file_3, email_file_4, email_file_5 FROM va_job_requests WHERE id='$id'")[0];
    $overwrites = array();
    foreach ($fileslots as $slot=>$value) {
        $overwrites[] = $slot;
    }
    $entries = rgar($entry,'2');
    $urls = array();
    $files = array();
    
    preg_match_all('/".*?"/', $entries, $urls);
    foreach ($urls[0] as $url) {
        $url = str_replace('"','', $url);
        $url = stripslashes($url);
        $files[] = $url;
    }
    
    function eslot($a) { //Looks for empty slot, returns if finds one.
        foreach ($a as $slot => $value) {
            if (empty($slot)) {
                return $slot;
            }
        }
        return false;
    }
    $slot = eslot($fileslots);
    
    for ($i=0; $i<count($files); $i++) {
        if ($slot === false) { //If no empty slot, overwrite all slots until count finished
           $wpdb->update('va_job_requests', array("$overwrites[$i]"=>$files[$i]), array('id'=>$id));
        }
        else { // Else, write in empty slot
            $wpdb->update('va_job_requests', array("$slot"=>$files[$i]), array('id'=>$id));
        }
    }
}

# ------------------------------
#
# TASK COMPLETE EMAIL FUNCTION
#
# ------------------------------

// $prehours, $taskhours, $remaininghours
function task_complete_email($formId, $taskid, $corpgroupid, $spec_user, $times, $corp_display_name, $corp_prehours, $corp_remaininghours, $caller_email, $caller_source) {
    global $wpdb;
    $task = $wpdb->get_results("SELECT * FROM va_job_requests WHERE id = $taskid")[0];
    $user = $wpdb->get_results("SELECT * FROM va_users WHERE ID = $task->user_id")[0];
    $client_name = $task->name;
    $client_email = $user->user_email;
    $attachments = array();
    $notes = $task->notes; 
    $category = $task->category;
    $title = $task->title;  
    $notes = $task->notes;
    $address1 = $task->address1;
    $address2 = $task->address2;
    // $source = $task->caller_source;
    $name = $task->caller_name;
    $email = $task->caller_email;
    $phone = $task->phone_number;
    $task_status = $task->task_status;
    
    // $referral = $task->referral;
     if(empty($task->description)){		
		$description = str_replace(["—","–"],'-', $va_entry['details']);
	} else{
		$description = str_replace(["—","–"],'-', $va_entry['Description']);
	}
    $description = $task->description;
    $starttime = $wpdb->get_results("SELECT DATE_FORMAT(task_start, '%c/%d/%Y - %l:%i %p') TIMEONLY FROM va_job_requests WHERE id = '$taskid'")[0]->TIMEONLY;
    $curdate = current_time("m/d/Y");
    $curtime = current_time("g:i A");
    $va = ($task->assigned_to != 'Not Assigned' ? $task->assigned_to : 'April Dodson');
    $va_email = $wpdb->get_results("SELECT email from va_assistants WHERE name = '$va'")[0]->email;
    $email_group = $task->email_group;
    $headers = array("Content-type: text/html; charset=UTF-8;","From: Bidslot VA <no-reply@bidslotprogram.com>","Cc: $email_group");

    for ($i=0; $i<5; $i++) {
        $file = "email_file_$i";
        if ($task->$file){$attachments[] = $task->$file;}
    };
    if ($task->file){$fileAttachment = $task->file;}
    $message = "<h2>Plan Update - $client_name</h2><hr size='1' width='100%' align='center'>";
    $message .= "<table border='0' cellpadding='0' width='100%' style='width:100.0%; table-layout:fixed;'><tbody>";
    
    if(!empty($client_email)) { $message .= "<tr>
                <td style='padding: .75pt'><strong><span style=\"font-family: 'Calibri', sans-serif';\">Email:</span></strong></td>
                <td style='padding: .75pt; margin-bottom: .75pt'>$client_email</td>
            </tr>";}
    $message .= "<tr><td><h3>Caller Info</h3></td></tr>";

		if (!empty($caller_email)) {
			$message .=  "<tr>
				<td style='padding: .75pt'><strong><span style=\"font-family: 'Calibri', sans-serif;\">Email:</span></strong></td>
				<td style='padding: .75pt'>$caller_email</td>
			</tr>"; 
        }
        if (!empty($caller_source)) {
			$message .=  "<tr>
				<td style='padding: .75pt'><strong><span style=\"font-family: 'Calibri', sans-serif;\">Source:</span></strong></td>
				<td style='padding: .75pt'>$caller_source</td>
			</tr>"; 
        }
        
        if(!empty($name)) { $message .= "<tr>
            <td style='padding: .75pt'><strong><span style=\"font-family: 'Calibri', sans-serif;\">Name:</span></strong></td>
            <td style='padding: .75pt'>$name</td>
        </tr>";}
        if(!empty($phone)) { $message .= "<tr>
            <td style='padding: .75pt'><strong><span style=\"font-family: 'Calibri', sans-serif;\">Number:</span></strong></td>
            <td style='padding: .75pt'>$phone</td>
        </tr>";}
        if(!empty($email)) { $message . "<tr>
            <td style='padding .75pt'><strong><span style=\"font-family: 'Calibri', sans-serif;\">Email:</span></strong></td>
            <td style='padding: .75pt'>$email</td>
        </tr>";}
    if(!empty($address1)) {
        $message .= "<tr>
                <td style='padding: .75pt'><strong><span style=\"font-family: 'Calibri', sans-serif;\">Address 1:</span><strong></td>
                <td style='padding: .75pt'>$address1</td>
            </tr>";
    }
    if(!empty($address2)) {
        $message .= "<tr>
                <td style='padding: .75pt'><strong><span style=\"font-family: 'Calibri', sans-serif;\">Address 2:</span><strong></td>
                <td style='padding: .75pt'>$address2</td>
            </tr>";
    }
    
        
    $message .= "<tr><td style='margin: 1.5pt'></td></tr></tbody></table>";
    
    if(!empty($task_status)) { $message .= "<h3>Task Status</h3><p>$task_status</p>"; }
    
    if(!empty($title)) { $message .= "<h3>Title</h3><p>$title</p>"; }
    if(!empty($description)) { $message .= "<h3>Description</h3><p>$description</p>"; }
    // if ($referral) { $message .= "<h3>How Did You Hear About Us?</h3><p>$referral</p>"; }

    $message .= "<table border='0' cellpadding='0' width='100%' style='width:100.0%; table-layout:fixed;'><tbody>
            <tr>
                <td style='padding:.75pt'><strong><span style=\"font-family:'Calibri',sans-serif;\">Date Completed:</span></strong></td>
                <td style='padding:.75pt'>$curdate - $curtime</td>
            </tr>";
    $message .= `<tr><td><h3>Hours</h3></td></tr>`;
    if(!empty($user->counter)) {//Modified by Micheal
        $message .= "<tr>
            <td style='padding:.75pt'><strong><span style=\"font-family:'Calibri',sans-serif;\">Message Count:</span></strong></td>
            <td style='padding:.75pt'>".$user->counter."</td>
        </tr>";
    }
    //} else {
        if ($spec_user === false) {
            $message .= "<tr>
                <td style='padding:.75pt'><strong><span style=\"font-family:'Calibri',sans-serif;\">Hours Before Task:</span></strong></td>
                <td style='padding:.75pt'>".sprintf('%02d hours %02d minutes', (int) $times['prehours'], round(fmod($times['prehours'], 1) * 60))."</td>
            </tr>";
        }
        $message .= "<tr>
                <td style='padding:.75pt'><strong><span style=\"font-family:'Calibri',sans-serif;\">Hours Used:</span></strong></td>
                <td style='padding:.75pt'>".sprintf('%02d hours %02d minutes', (int) $times['taskhours'], round(fmod($times['taskhours'], 1) * 60))."</td>
            </tr>";
    
        if($spec_user === false) {
            $message .= "<tr>
                <td style='padding:.75pt'><strong><span style=\"font-family:'Calibri',sans-serif;\">Hours Remaining This Subscription Period:</span></strong></td>
                <td style='padding:.75pt'>".sprintf('%02d hours %02d minutes', (int) $times['remaininghours'], round(fmod($times['remaininghours'], 1) * 60))."</td>
            </tr>";
        }
    //}
    if ($corpgroupid) {
        $message .= "<tr><td><h3>Corporate Hours - $corp_display_name</h3></td></tr>";
        $message .= "<tr>
            <td style='padding:.75pt'><strong><span style=\"font-family:'Calibri',sans-serif;\">Hours Before Task:</span></strong></td>
            <td style='padding:.75pt'>".sprintf('%02d hours %02d minutes', (int) $corp_prehours, round(fmod($corp_prehours, 1) * 60))."</td>
        </tr>";
        $message .= "
        </tr>
            <td style='padding:.75pt'><strong><span style=\"font-family:'Calibri',sans-serif;\">Hours Remaining This Subscription Period:</span></strong></td>
            <td style='padding:.75pt'><b>".sprintf('%02d hours %02d minutes', (int) $corp_remaininghours, round(fmod($corp_remaininghours, 1) * 60))."</b></td>
        </tr>";
    };
    $message .= "</tbody></table>";
    
    if($notes){ $message .= "<h3>Additional Notes</h3><p>$notes</p>"; }
    $message .= "<table border='0' cellpadding='0' width='100%' style='width:100.0%; table-layout:fixed;'><tbody>";
    $message .= "<tr><td><h3>Additional Fields</h3></td></tr>";
    $message .="";
        if(!empty($category)) { $message .= `<tr><td>Category</td><td>$category</td></tr>`;}
        if(!empty($task->caller_type)) { $message .= "<tr><td>Caller Type</td><td>".$task->caller_type."</td></tr>";};
        if($task->college_ID_number != 0){ $message .= "<tr><td>College ID Number</td><td>".$task->college_ID_number."</td></tr>";};
        if(!empty($task->SCC_Username)){ $message .= "<tr><td>SCC Username</td><td>".$task->SCC_Username."</td></tr>";};
        $message .= "</tbody>
    </table>
    <br/>
    <a href=$site_url.'wp-login.php?action=login&redirect_to='.$site_url.'task-details/?id=$taskid'>Login To View Request</a>
    <br/><br/><ul>";
            for ($i=0; $i<count($attachments); $i++) {
                $j = $i+1;
                $message .= "<li><a target='_blank' href='$attachments[$i]'>File $j</a></li>";
            };
        $message .= "</ul>";
    if(!empty($fileAttachment)) {
        $message .= "<h3>Uploaded Files</h3>
        <blockquote padding:10px;'><li><a target='_blank' href='$fileAttachment'>Uploads</a></li></blockquote>";
    }

    $message .= "<div style='display:block; text-align:center; font-style:italic;'>If you have any further questions, feel free to contact $va regarding this task at office@bidslotmarketingcorp.com. Thanks!</div>";

    wp_mail($client_email, 'Bidslot VA - Task Receipt', $message, $headers);
    wp_mail('april@bidslotmarketingcorp.com', 'Bidslot VA - Task Receipt', $message, $headers);
    
    // if(!empty($email)){
    //     wp_mail($email, 'Bidslot VA - Task Receipt', $message, $headers);
    // }
}

# ------------------------------------------------------------------
#
# PREPOPULATE NAMES FOR ADMIN JOB REQUEST FORM
#
# ------------------------------------------------------------------

add_filter('gform_pre_render', 'populate_clients');
add_filter('gform_pre_validation','populate_clients');
add_filter('gform_admin_pre_render', 'populate_clients');
add_filter('gform_pre_submission_filter', 'populate_clients');

function populate_clients($form) {
    
    global $wpdb;    
    
    $choices = array();
    $qchoices = array();
    
    //db calls
    $users = $wpdb->get_results("SELECT display_name, u.ID FROM va_users u LEFT JOIN va_assistants a ON u.ID = a.id WHERE a.id IS NULL AND u.user_status = 1 ORDER BY display_name ASC");
    $companies = $wpdb->get_results("SELECT user_id, meta_value FROM va_usermeta WHERE meta_key = 'billing_company'");
    $qagents =  $wpdb->get_results("SELECT a.name, a.id FROM va_assistants a LEFT JOIN va_users u ON a.id = u.ID WHERE u.user_status = 1 ORDER BY name ASC");
    
    if ($form['title'] != "Admin Request Form" && $form['title'] != "Admin Quickrequest Updated" && $form['title'] != "Admin Request Updated" && $form['title'] != "Admin Quickrequest Updated") return $form;
    
    $choices[] = array('text'=>'---', 'value'=>'---');
    $qchoices[] = array('text'=>'---', 'value'=>'---');
    $agents[] = array('text'=>'---', 'value'=>'---');
    
    foreach($form['fields'] as &$field) {
        if ($field->id == 1 || $field->placeholder == 'clients') {
            foreach ($users as $user) {
				$client = $user->display_name;
				$client_id = $user->ID;
				array_push($choices, array('text'=>$client, 'value'=>$client_id, 'isSelected'=>false));
			};
			$field['choices'] = $choices;
        };
        
        if($field->placeholder == 'Companies'){
			foreach ($companies as $co) {
				if(!$co->meta_value == NULL){	
					$client = $co->meta_value;
					$client_id = $co->user_id;
					array_push($qchoices, array('text'=>$client, 'value'=>$client_id, 'isSelected'=>false));
				}
			};
			$field['choices'] = $qchoices;		
        }
        if($field->placeholder == 'Agents'){
			foreach ($qagents as $qa) {
				if(!$qa->name == NULL){	
					$agent = $qa->name;
					$agent_id = $qa->id;
					array_push($agents, array('text'=>$agent, 'value'=>$agent, 'isSelected'=>false));
				}
			};
			$field['choices'] = $agents;		
        }
       
    };
    return $form;
}

# ---------------------------------------
# SEND CLIENT RENEW FORM
# ---------------------------------------

add_action('gform_after_submission_12', 'send_renew_hours', 10, 2);

function send_renew_hours($entry, $form) {
    global $wpdb;
    $id = $_GET['id'];
    $task = $wpdb->get_results("SELECT name, email, title, assigned_to FROM `va_job_requests` WHERE id='$id'")[0];
    $taskname = $task->name;
    $taskemail = $task->email;
    $va = $task->assigned_to;
    $remaininghours = $wpdb->get_results("SELECT hours FROM `va_users` WHERE user_email = '$taskemail'")[0]->hours;
    $tasktitle = $task->title;
    $expectedhrs = rgar($entry, '3');
    $vaemail = rgar($entry,'6');
    $headers[] = "Content-type: text/html";
    $headers[] = "Reply-To: $va <$vaemail>";

    $message = "Hello $taskname,<br/><br/>\n
    You do not have enough hours or available messages left in this subscription to complete this request.<br/><br/>\n
    <table>\n
    <tr>\n
    <td>Job Request Title: </td><td id='email-jtitle'>$tasktitle</td></tr>\n
    <tr>\n
    <td>Expected Hours: </td><td id='email-jhours'>$expectedhrs</td></tr>\n
    <tr>\n
    <td>Available Hours: </td><td id='email-rhours'>$remaininghours</td>\n
    </tr></table><br/><br/>\n
    To upgrade your package click here. <a href=$site_url.'shop'>$site_url</a><br/>\n
    To cancel this request, reply to this email.";


    wp_mail($taskemail, 'Bidslot VA - Please Renew Your Hours', $message, $headers);
    wp_mail($vaemail, 'Bidslot VA - Please Renew Your Hours [Copy]', $message, $headers);
    wp_mail('april@bidslotmarketingcorp.com', 'Bidslot VA - Please Renew Your Hours [Copy]', $message, $headers);
}

# -----------------------------------------------------
#
# CREATE CORPORATE & SUPER ADMIN USER ROLE
#
# -----------------------------------------------------


add_role('subscriber',__('Subscriber'),
    array(
      'read'    => true
    )
);

$corporate = add_role('corporate', __('Corporate'),
  array(
      'read'    => true
  ) 
);

add_role('Administrator',__('Administrator'),
    array(
        'list_users'    => true,         
        'read'          => true
    )
);

add_role('super_admin',__('Super Admin'),
    array(
        'activate_plugins'          => true,
        'delete_others_pages'       => true,
        'delete_others_posts'       => true,
        'delete_pages'              => true,
        'delete_posts'              => true,
        'delete_private_pages'      => true,
        'delete_private_posts'      => true,
        'delete_published_pages'    => true,
        'delete_published_posts'    => true,
        'edit_dashboard'            => true,
        'edit_others_pages'         => true,
        'edit_others_posts'         => true,
        'edit_pages'                => true,
        'edit_posts'                => true,
        'edit_private_pages'        => true,
        'edit_private_posts'        => true,
        'edit_published_pages'      => true,
        'edit_published_posts'      => true,
        'edit_theme_options'        => true,
        'export'                    => true,
        'import'                    => true,
        'list_users'                => true,
        'manage_categories'         => true,
        'manage_links'              => true,
        'manage_options'            => true,
        'moderate_comments'         => true,
        'promote_users'             => true,
        'publish_pages'             => true,
        'publish_posts'             => true,
        'read_private_pages'        => true,
        'read_private_posts'        => true,
        'read'                      => true,
        'remove_users'              => true,
        'switch_themes'             => true,
        'upload_files'              => true,
        'customize'                 => true,
        'delete_site'               => true,  
        'update_core'               => true,
        'update_plugins'            => true,
        'update_themes'             => true,
        'install_plugins'           => true,
        'install_themes'            => true,
        'upload_plugins'            => true,
        'upload_themes'             => true,
        'delete_themes'             => true,
        'delete_plugins'            => true,
        'edit_plugins'              => true,
        'edit_themes'               => true,
        'edit_files'                => true,
        'edit_users'                => true,
        'create_users'              => true,
        'delete_users'              => true,
        'unfiltered_html'           => true,
        'manage_woocommerce'        => true,
        'view_woocommerce_reports'  => true
    )                
);


# -----------------------------------------------------
#
# ALLOW "SUPER ADMINS" TO EDIT ALL USERS
#
# -----------------------------------------------------

function mc_admin_users_caps( $caps, $cap, $user_id, $args ){
 
    foreach( $caps as $key => $capability ){
 
        if( $capability != 'do_not_allow' )
            continue;
 
        switch( $cap ) {
            case 'edit_user':
            case 'edit_users':
                $caps[$key] = 'edit_users';
                break;
            case 'delete_user':
            case 'delete_users':
                $caps[$key] = 'delete_users';
                break;
            case 'create_users':
                $caps[$key] = $cap;
                break;
        }
    }
 
    return $caps;
}
add_filter( 'map_meta_cap', 'mc_admin_users_caps', 10, 4 );

# -----------------------------------------------------
#
# INSERT CORPORATE ACCOUNTS IN USER SELECT LIST
#
# -----------------------------------------------------

function acf_insert_corporate_accounts($field) {
    $field['choices'] = array();
    
    $users = get_users(array('role'=>'corporate'));
    
    foreach ($users as $user) {
        $key = $user->data->display_name;
        $id = $user->data->ID;
        $field['choices'][$id] = $key;
    };
    
    return $field;
}

add_filter('acf/load_field/name=corporate_group', 'acf_insert_corporate_accounts');

// AUTO COMPLETE PAID ORDERS IN WOOCOMMERCE (Based on payment methods)
add_action( 'woocommerce_thankyou', 'custom_woocommerce_auto_complete_paid_order', 20, 1 );
function custom_woocommerce_auto_complete_paid_order( $order_id ) {
    if ( ! $order_id )
        return;

    // Getting the $order object from the ID
    $order = wc_get_order( $order_id );

    // Getting the custom meta value regarding this autocomplete status process
    $order_processed = get_post_meta($order->id, '_order_processed', true);

    // No updated status for orders delivered with Bank wire, Cash on delivery and Cheque payment methods.
    if ( ( get_post_meta($order->id, '_payment_method', true) == 'bacs' ) || ( get_post_meta($order->id, '_payment_method', true) == 'cod' ) || ( get_post_meta($order->id, '_payment_method', true) == 'cheque' ) ) {
        return;
    }
    else
    {
        // We check if order has a status different than completed AND if the custom meta value hasen't been already set
        if (!$order->has_status( 'completed' ) && $order_processed != 'yes'){
            // setting the custom meta data value to yes (order updated)
            update_post_meta($order->id, '_order_processed', 'yes');
            $order->update_status( 'completed' ); // Update order status to completed
        } else {
            return;
        }
    }
}
//SCAN ALL "processing" orders status (to auto-complete them)
add_action( 'init', 'auto_update_orders_status_from_processing_to_completed' );
function auto_update_orders_status_from_processing_to_completed(){

    // Get all current "processing" customer orders
    $processing_orders = wc_get_orders( array(
        'numberposts' => -1,
        'post_status' => 'wc-processing',
    ) );

    if(!empty($processing_orders)){
        foreach($processing_orders as $order) {
            // Checking if this custom field value is set in the order meta data
            $order_processed = get_post_meta($order->id, '_order_processed', true);
            if (!$order->has_status( 'completed' ) && $order_processed != 'yes') {
                // Setting (updating) custom meta value in the order metadata to avoid repetitions
                update_post_meta($order->id, '_order_processed', 'yes');
                $order->update_status( 'completed' ); // Updating order status
            }
        }
    }
}

add_action('wp_footer','custom_script');
function custom_script(){
	?>
<script>
jQuery(window).on("load",function(){
jQuery('template#MDow-1').next().next().hide();
})
</script>
<?php
}


?>
